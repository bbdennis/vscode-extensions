import isort.main
isort.main.main()